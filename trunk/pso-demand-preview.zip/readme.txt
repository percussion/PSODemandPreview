This is the PSO Demand Publishing Preview Project for Rhythmyx 6.7 

THIS VERSION REQUIRES RHYTHMYX 6.7 OR LATER 

To deploy the toolkit, unzip the distribution into an empty directory. 

You must have Java 1.5 and Apache Ant properly installed. 

The RHYTHMYX_HOME environment variable must point at your 
Rhythmyx 6.7 installation.  

Type the command: 

ant -f deploy.xml 

See the PROJECT-HOW-TO.html file for further information. 